# NHRA Drag Racing 3D (PSP / PPSSPP)

Jogo de arrancada 3D em C (PSPSDK), visual low-poly estilo PSP: Top Fuel, Funny Car e Pro Stock,
arvore de largada (Pro e Sportsman), reacao, troca de marchas, timeslip (60 / 330 / 660 / 1000 ft)
e oponente CPU (facil, medio, dificil). Fan game, sem relacao com a NHRA.

## Controles
- CIMA .......... andar ate a linha (estagiar)
- QUADRADO ...... freio de largada: segure e SOLTE no verde
- X ............. acelerar / girar o motor (rpm ideal antes da largada = faixa amarela)
- R ............. trocar de marcha (ideal: barra verde, antes do vermelho)
- START pausa, SELECT menu

## Como gerar o EBOOT.PBP (sem instalar nada)
1. Crie um repositorio no GitHub e envie TODOS os arquivos desta pasta (inclusive a pasta `.github`).
2. Abra a aba **Actions** do repositorio. O build "Build EBOOT.PBP" roda sozinho (ou clique em *Run workflow*).
3. Quando terminar, baixe o artefato **NHRA3D-PSP** (zip) e extraia.
4. No PPSSPP: *Abrir* -> escolha `NHRA3D/EBOOT.PBP`.

## Compilar no PC (opcional)
Com o toolchain pspdev instalado: `make` gera o `EBOOT.PBP`.
