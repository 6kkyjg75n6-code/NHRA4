/*
 * NHRA Drag Racing 3D  -  PSP homebrew (PSPSDK) - roda no PPSSPP
 * Fan game, sem relacao com a NHRA.
 *
 * Controles:
 *   CIMA ........ andar ate a linha (estagiar)
 *   QUADRADO .... freio de largada (segure; SOLTE no verde)
 *   X ........... acelerar / girar o motor
 *   R ........... trocar marcha
 *   START ....... pausa     SELECT ... volta ao menu
 */
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspgu.h>
#include <pspgum.h>
#include <psprtc.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

PSP_MODULE_INFO("NHRA3D", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

#define SCR_W 480
#define SCR_H 272
#define BUF_W 512
#define PI_F 3.14159265f

/* ------------------------------------------------------------------ */
/* callbacks (HOME / sair)                                             */
/* ------------------------------------------------------------------ */
static int exit_callback(int a1, int a2, void *c)
{
    (void)a1; (void)a2; (void)c;
    sceKernelExitGame();
    return 0;
}
static int callback_thread(SceSize args, void *argp)
{
    (void)args; (void)argp;
    int cb = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cb);
    sceKernelSleepThreadCB();
    return 0;
}
static void setup_callbacks(void)
{
    int th = sceKernelCreateThread("update_thread", callback_thread, 0x11, 0xFA0, 0, 0);
    if (th >= 0) sceKernelStartThread(th, 0, 0);
}

/* ------------------------------------------------------------------ */
/* GU basico                                                           */
/* ------------------------------------------------------------------ */
static unsigned int __attribute__((aligned(16))) dlist[262144];

typedef struct { unsigned int c; float x, y, z; } V;
#define VT3 (GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D)
#define VT2 (GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D)

#define POOLN 60000
static V pool[POOLN] __attribute__((aligned(64)));
static int pn = 0;

static V *alloc_v(int n)
{
    if (pn + n > POOLN) return 0;
#ifdef HOST_TEST
    V *r = &pool[pn];
#else
    V *r = (V *)((unsigned int)&pool[pn] | 0x40000000u); /* uncached */
#endif
    pn += n;
    return r;
}

#define RGBA(r,g,b,a) (((unsigned)(a)<<24)|((unsigned)(b)<<16)|((unsigned)(g)<<8)|(unsigned)(r))
#define RGB(r,g,b) RGBA(r,g,b,255)

static unsigned shade(unsigned c, float f)
{
    unsigned r = c & 255, g = (c >> 8) & 255, b = (c >> 16) & 255, a = c >> 24;
    r = (unsigned)(r * f); g = (unsigned)(g * f); b = (unsigned)(b * f);
    if (r > 255) r = 255;
    if (g > 255) g = 255;
    if (b > 255) b = 255;
    return (a << 24) | (b << 16) | (g << 8) | r;
}

static float camZ = 0.0f;
static int cullOn = 1;

static void addq(V *v, int *n, unsigned c, float q[4][3])
{
    static const int idx[6] = {0, 1, 2, 0, 2, 3};
    int i;
    for (i = 0; i < 6; i++) {
        V *o = &v[(*n)++];
        o->c = c;
        o->x = q[idx[i]][0];
        o->y = q[idx[i]][1];
        o->z = q[idx[i]][2];
    }
}

/* caixa: x,z = centro ; y = base ; w(x) h(y) d(z) */
static void box(float x, float y, float z, float w, float h, float d, unsigned col)
{
    if (cullOn && (z + d * 0.5f < camZ - 25.0f)) return;
    V *v = alloc_v(30);
    if (!v) return;
    float x0 = x - w * 0.5f, x1 = x + w * 0.5f;
    float y0 = y, y1 = y + h;
    float z0 = z - d * 0.5f, z1 = z + d * 0.5f;
    float q[4][3];
    int n = 0;
#define SQ(a0,a1,a2,b0,b1,b2,c0,c1,c2,d0,d1,d2) \
    q[0][0]=a0;q[0][1]=a1;q[0][2]=a2; q[1][0]=b0;q[1][1]=b1;q[1][2]=b2; \
    q[2][0]=c0;q[2][1]=c1;q[2][2]=c2; q[3][0]=d0;q[3][1]=d1;q[3][2]=d2;
    SQ(x0,y1,z0, x1,y1,z0, x1,y1,z1, x0,y1,z1)  addq(v, &n, shade(col, 1.00f), q);
    SQ(x0,y0,z1, x1,y0,z1, x1,y1,z1, x0,y1,z1)  addq(v, &n, shade(col, 0.85f), q);
    SQ(x0,y0,z0, x1,y0,z0, x1,y1,z0, x0,y1,z0)  addq(v, &n, shade(col, 0.78f), q);
    SQ(x0,y0,z0, x0,y0,z1, x0,y1,z1, x0,y1,z0)  addq(v, &n, shade(col, 0.68f), q);
    SQ(x1,y0,z0, x1,y0,z1, x1,y1,z1, x1,y1,z0)  addq(v, &n, shade(col, 0.62f), q);
#undef SQ
    sceGumDrawArray(GU_TRIANGLES, VT3, n, 0, v);
}

/* plano horizontal (sem depth) */
static void plane(float x0, float z0, float x1, float z1, float y, unsigned col)
{
    V *v = alloc_v(6);
    if (!v) return;
    float q[4][3] = {{x0, y, z0}, {x1, y, z0}, {x1, y, z1}, {x0, y, z1}};
    int n = 0;
    addq(v, &n, col, q);
    sceGumDrawArray(GU_TRIANGLES, VT3, n, 0, v);
}

/* piramide (montanhas) */
static void pyramid(float x, float z, float w, float h, unsigned col)
{
    V *v = alloc_v(12);
    if (!v) return;
    float hw = w * 0.5f;
    float ax = x - hw, bx = x + hw, az = z - hw, bz = z + hw;
    int n = 0;
#define TRI(cc,x0,y0,z0,x1,y1,z1,x2,y2,z2) \
    v[n].c=(cc);v[n].x=x0;v[n].y=y0;v[n].z=z0;n++; \
    v[n].c=(cc);v[n].x=x1;v[n].y=y1;v[n].z=z1;n++; \
    v[n].c=(cc);v[n].x=x2;v[n].y=y2;v[n].z=z2;n++;
    TRI(shade(col, 0.95f), ax, 0, az, bx, 0, az, x, h, z)
    TRI(shade(col, 0.80f), bx, 0, az, bx, 0, bz, x, h, z)
    TRI(shade(col, 0.65f), bx, 0, bz, ax, 0, bz, x, h, z)
    TRI(shade(col, 0.85f), ax, 0, bz, ax, 0, az, x, h, z)
#undef TRI
    sceGumDrawArray(GU_TRIANGLES, VT3, n, 0, v);
}

/* roda: cilindro ao longo de X */
#define WN 10
static void wheel(float cx, float cy, float cz, float r, float w, float rot)
{
    V *v = alloc_v(WN * 6 + WN * 6);
    if (!v) return;
    int n = 0, i, s;
    for (i = 0; i < WN; i++) {
        float a0 = rot + i * (2.0f * PI_F / WN);
        float a1 = rot + (i + 1) * (2.0f * PI_F / WN);
        float y0 = cy + r * cosf(a0), z0 = cz + r * sinf(a0);
        float y1 = cy + r * cosf(a1), z1 = cz + r * sinf(a1);
        float q[4][3] = {{cx - w * 0.5f, y0, z0}, {cx + w * 0.5f, y0, z0},
                         {cx + w * 0.5f, y1, z1}, {cx - w * 0.5f, y1, z1}};
        addq(v, &n, (i & 1) ? RGB(46, 46, 50) : RGB(28, 28, 30), q);
        for (s = -1; s <= 1; s += 2) {
            float xx = cx + s * w * 0.5f;
            unsigned c = (i & 1) ? RGB(215, 215, 220) : RGB(140, 140, 150);
            v[n].c = c; v[n].x = xx; v[n].y = cy; v[n].z = cz; n++;
            v[n].c = c; v[n].x = xx; v[n].y = y0; v[n].z = z0; n++;
            v[n].c = c; v[n].x = xx; v[n].y = y1; v[n].z = z1; n++;
        }
    }
    sceGumDrawArray(GU_TRIANGLES, VT3, n, 0, v);
}

/* ------------------------------------------------------------------ */
/* Fonte 5x7 (bit0 = linha de cima)  ASCII 0x20..0x5A                  */
/* ------------------------------------------------------------------ */
static const unsigned char font[59][5] = {
    {0x00,0x00,0x00,0x00,0x00},{0x00,0x00,0x5F,0x00,0x00},{0x00,0x07,0x00,0x07,0x00},
    {0x14,0x7F,0x14,0x7F,0x14},{0x24,0x2A,0x7F,0x2A,0x12},{0x23,0x13,0x08,0x64,0x62},
    {0x36,0x49,0x56,0x20,0x50},{0x00,0x05,0x03,0x00,0x00},{0x00,0x1C,0x22,0x41,0x00},
    {0x00,0x41,0x22,0x1C,0x00},{0x2A,0x1C,0x7F,0x1C,0x2A},{0x08,0x08,0x3E,0x08,0x08},
    {0x00,0x50,0x30,0x00,0x00},{0x08,0x08,0x08,0x08,0x08},{0x00,0x60,0x60,0x00,0x00},
    {0x20,0x10,0x08,0x04,0x02},
    {0x3E,0x51,0x49,0x45,0x3E},{0x00,0x42,0x7F,0x40,0x00},{0x72,0x49,0x49,0x49,0x46},
    {0x21,0x41,0x49,0x4D,0x33},{0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},
    {0x3C,0x4A,0x49,0x49,0x31},{0x41,0x21,0x11,0x09,0x07},{0x36,0x49,0x49,0x49,0x36},
    {0x46,0x49,0x49,0x29,0x1E},
    {0x00,0x36,0x36,0x00,0x00},{0x00,0x56,0x36,0x00,0x00},{0x08,0x14,0x22,0x41,0x00},
    {0x14,0x14,0x14,0x14,0x14},{0x00,0x41,0x22,0x14,0x08},{0x02,0x01,0x59,0x09,0x06},
    {0x3E,0x41,0x5D,0x59,0x4E},
    {0x7C,0x12,0x11,0x12,0x7C},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},
    {0x7F,0x41,0x41,0x41,0x3E},{0x7F,0x49,0x49,0x49,0x41},{0x7F,0x09,0x09,0x09,0x01},
    {0x3E,0x41,0x41,0x51,0x73},{0x7F,0x08,0x08,0x08,0x7F},{0x00,0x41,0x7F,0x41,0x00},
    {0x20,0x40,0x41,0x3F,0x01},{0x7F,0x08,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
    {0x7F,0x02,0x1C,0x02,0x7F},{0x7F,0x04,0x08,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},
    {0x7F,0x09,0x09,0x09,0x06},{0x3E,0x41,0x51,0x21,0x5E},{0x7F,0x09,0x19,0x29,0x46},
    {0x26,0x49,0x49,0x49,0x32},{0x03,0x01,0x7F,0x01,0x03},{0x3F,0x40,0x40,0x40,0x3F},
    {0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,0x08,0x14,0x63},
    {0x03,0x04,0x78,0x04,0x03},{0x61,0x59,0x49,0x4D,0x43}
};

static int glyph(char c)
{
    if (c >= 'a' && c <= 'z') c = (char)(c - 32);
    if (c < 32 || c > 90) return 0;
    return c - 32;
}

static void rect(int x, int y, int w, int h, unsigned col)
{
    V *v = alloc_v(2);
    if (!v) return;
    v[0].c = col; v[0].x = (float)x;       v[0].y = (float)y;       v[0].z = 0;
    v[1].c = col; v[1].x = (float)(x + w); v[1].y = (float)(y + h); v[1].z = 0;
    sceGuDrawArray(GU_SPRITES, VT2, 2, 0, v);
}

static void text_raw(int x, int y, int s, unsigned col, const char *str)
{
    int n = 0, i, cx, ry;
    const char *p;
    for (p = str; *p; p++) {
        int g = glyph(*p);
        for (cx = 0; cx < 5; cx++)
            for (ry = 0; ry < 7; ry++)
                if (font[g][cx] & (1 << ry)) n++;
    }
    if (n == 0) return;
    V *v = alloc_v(n * 2);
    if (!v) return;
    i = 0;
    int px = x;
    for (p = str; *p; p++) {
        int g = glyph(*p);
        for (cx = 0; cx < 5; cx++)
            for (ry = 0; ry < 7; ry++)
                if (font[g][cx] & (1 << ry)) {
                    v[i].c = col; v[i].x = (float)(px + cx * s); v[i].y = (float)(y + ry * s); v[i].z = 0; i++;
                    v[i].c = col; v[i].x = (float)(px + cx * s + s); v[i].y = (float)(y + ry * s + s); v[i].z = 0; i++;
                }
        px += 6 * s;
    }
    sceGuDrawArray(GU_SPRITES, VT2, n * 2, 0, v);
}

static void text(int x, int y, int s, unsigned col, const char *str)
{
    int o = (s >= 3) ? 2 : 1;
    text_raw(x + o, y + o, s, RGB(0, 0, 0), str);
    text_raw(x, y, s, col, str);
}

static void textC(int y, int s, unsigned col, const char *str)
{
    int w = (int)strlen(str) * 6 * s - s;
    text((SCR_W - w) / 2, y, s, col, str);
}

/* ------------------------------------------------------------------ */
/* Dados do jogo                                                       */
/* ------------------------------------------------------------------ */
typedef struct {
    const char *name;
    float a0, V, vtop;      /* modelo de aceleracao */
    int gears;
    float ra;               /* eixo traseiro (distancia do nariz) */
    float rrad;             /* raio roda traseira */
    float wheelie;          /* pitch maximo */
} Cls;

static const Cls cls[3] = {
    {"TOP FUEL",  54.09f, 197.35f, 158.4f, 3, 6.2f, 0.50f, 0.22f},
    {"FUNNY CAR", 48.07f, 217.93f, 156.7f, 3, 6.3f, 0.50f, 0.18f},
    {"PRO STOCK", 15.23f, 278.26f,  98.0f, 5, 3.7f, 0.33f, 0.04f}
};

#define LANE_P  3.5f    /* jogador (esquerda da tela) */
#define LANE_C -3.5f    /* oponente */
#define STAGE_Z (-0.28f)
#define PRESTAGE_Z (-1.1f)
#define TRACK_LEN 304.8f
#define MS2MPH 2.23694f
#define H_STEP (1.0f / 240.0f)

typedef struct {
    float z, v, wheel, pitch;
    int gear, pre, staged, launched, foul, finished, timerOn;
    float launchT, rt, lf, shiftCut, rn;
    float timer, et, mph;
    float t60, t330, t660, mph660;
    float finishT;
    /* IA */
    float aiRT, aiShiftAt, aiStageAt;
} Car;

enum { PH_MENU, PH_STAGE, PH_WAIT, PH_TREE, PH_DONE };

int phase = PH_MENU;
static int menuRow = 0, selClass = 0, selTree = 0, selDiff = 1;
static int paused = 0, armed = 0;
Car P, C;
static float simT = 0, camT = 0, acc = 0;
static float treeT0 = 1e9f, greenT = 1e9f, waitUntil = 0;
static float rev = 0;
static float bestET[3] = {0, 0, 0};
static const char *fbMsg = "";
static float fbT = 0;
static int winner = 0;           /* 1 = jogador, 2 = CPU */
static float winMargin = 0;
static float doneT = 0;

static float frand(void) { return (float)(rand() & 0x7FFF) / 32767.0f; }

static void reset_car(Car *c, float z)
{
    memset(c, 0, sizeof(Car));
    c->z = z;
    c->gear = 1;
    c->lf = 1.0f;
    c->pitch = 0;
    c->t60 = c->t330 = c->t660 = 0;
}

static void show_cars_staged(void)
{
    reset_car(&P, STAGE_Z);
    reset_car(&C, STAGE_Z);
    P.pre = P.staged = 1;
    C.pre = C.staged = 1;
}

static void start_race(void)
{
    reset_car(&P, -9.0f);
    reset_car(&C, -9.0f);
    phase = PH_STAGE;
    paused = 0;
    armed = 0;
    rev = 0;
    treeT0 = 1e9f;
    greenT = 1e9f;
    acc = 0;
    fbT = 0;
    winner = 0;
    C.aiStageAt = simT + 1.0f + frand() * 2.5f;
    {
        float r = frand();
        if (selDiff == 0)      { C.aiRT = 0.12f + r * 0.22f; }
        else if (selDiff == 1) { C.aiRT = 0.05f + r * 0.12f; }
        else                   { C.aiRT = 0.015f + r * 0.05f; }
    }
    C.aiShiftAt = 0.95f;
}

/* ------------------------------------------------------------------ */
/* Logica                                                              */
/* ------------------------------------------------------------------ */
static float launch_factor(float r)
{
    if (r < 0.72f) return 0.6f + 0.4f * (r / 0.72f);
    if (r <= 0.88f) return 1.0f;
    {
        float f = 1.0f - (r - 0.88f) * 3.5f;
        return f < 0.55f ? 0.55f : f;
    }
}

static void do_launch(Car *c, float lf)
{
    c->launched = 1;
    c->launchT = 0;
    c->lf = lf;
    c->rt = simT - greenT;
    if (c->rt < 0) c->foul = 1;
}

static float next_shift(void)
{
    float r = frand();
    if (selDiff == 0) return 0.80f + r * 0.24f;
    if (selDiff == 1) return 0.90f + r * 0.10f;
    return 0.95f + r * 0.045f;
}

static void step_car(Car *c, int isPlayer, int throttle, float h)
{
    const Cls *k = &cls[selClass];
    float gt = k->vtop * (float)c->gear / (float)k->gears;
    float p, L, a, x, zprev;

    c->rn = c->v / gt;
    if (c->rn > 1.0f) {
        p = 1.0f - (c->rn - 1.0f) * 6.0f;
        if (p < 0.25f) p = 0.25f;
    } else if (c->rn < 0.6f) {
        p = 0.6f + 0.4f * (c->rn / 0.6f);
    } else {
        p = 1.0f;
    }
    if (c->shiftCut > 0) { c->shiftCut -= h; p = 0; }

    /* IA troca de marcha */
    if (!isPlayer && !c->finished && c->gear < k->gears && c->rn >= c->aiShiftAt) {
        c->gear++;
        c->shiftCut = 0.09f;
        c->aiShiftAt = next_shift();
    }

    L = c->lf + (1.0f - c->lf) * (c->launchT / 1.8f > 1.0f ? 1.0f : c->launchT / 1.8f);
    x = c->v / k->V;

    if (c->finished)      a = -26.0f;
    else if (!throttle)   a = -4.0f;
    else                  a = k->a0 * (1.0f - x * x) * p * L;

    zprev = c->z;
    c->v += a * h;
    if (c->v < 0) c->v = 0;
    c->z += c->v * h;
    c->launchT += h;

    /* rodas / pitch */
    {
        float spin = (c->lf < 0.9f && c->launchT < 1.5f) ? 2.2f : 1.0f;
        float target = k->wheelie * c->lf * (c->launchT < 2.2f ? expf(-c->launchT * 1.1f) : 0.0f);
        c->wheel += c->v / k->rrad * spin * h;
        c->pitch += (target - c->pitch) * (h * 7.0f);
    }

    /* cronometragem */
    if (!c->finished) {
        float tprev = c->timerOn ? c->timer : 0.0f;
        if (!c->timerOn && c->z >= 0.0f) {
            c->timerOn = 1;
            c->timer = h * (c->z / (c->z - zprev));
        } else if (c->timerOn) {
            c->timer += h;
        }
        if (c->timerOn) {
            static const float bd[3] = {18.288f, 100.584f, 201.168f};
            float *dst[3];
            int i;
            dst[0] = &c->t60; dst[1] = &c->t330; dst[2] = &c->t660;
            for (i = 0; i < 3; i++)
                if (zprev < bd[i] && c->z >= bd[i] && *dst[i] == 0.0f) {
                    float fr = (bd[i] - zprev) / (c->z - zprev);
                    *dst[i] = tprev + h * fr;
                    if (i == 2) c->mph660 = c->v * MS2MPH;
                }
            if (zprev < TRACK_LEN && c->z >= TRACK_LEN) {
                float fr = (TRACK_LEN - zprev) / (c->z - zprev);
                c->et = tprev + h * fr;
                c->mph = c->v * MS2MPH;
                c->finishT = simT + h * (fr - 1.0f);
                c->finished = 1;
            }
        }
    }
    if (c->z > 620.0f) { c->z = 620.0f; c->v = 0; }
}

static void finish_race(void)
{
    phase = PH_DONE;
    doneT = simT;
    if (P.foul) { winner = 2; winMargin = 0; }
    else if (!C.finished) { winner = 1; winMargin = 0; }
    else if (!P.finished) { winner = 2; winMargin = 0; }
    else if (P.finishT <= C.finishT) { winner = 1; winMargin = C.finishT - P.finishT; }
    else { winner = 2; winMargin = P.finishT - C.finishT; }
    if (P.finished && !P.foul && (bestET[selClass] == 0.0f || P.et < bestET[selClass]))
        bestET[selClass] = P.et;
}

static int throttleHeld = 0;

static void sim_tick(float h)
{
    simT += h;

    if (phase == PH_WAIT && simT >= waitUntil) {
        phase = PH_TREE;
        treeT0 = simT;
        greenT = treeT0 + (selTree == 0 ? 0.4f : 1.5f);
    }

    /* CPU larga */
    if (phase == PH_TREE && !C.launched && simT >= greenT + C.aiRT) {
        float r = frand(), lf;
        if (selDiff == 0)      lf = 0.78f + r * 0.15f;
        else if (selDiff == 1) lf = 0.90f + r * 0.10f;
        else                   lf = 0.97f + r * 0.03f;
        do_launch(&C, lf);
        C.aiShiftAt = next_shift();
    }

    if (P.launched) step_car(&P, 1, throttleHeld && !P.finished, h);
    if (C.launched) step_car(&C, 0, 1, h);

    if ((phase == PH_TREE || phase == PH_WAIT) && P.launched) {
        int pdone = P.finished;
        int cdone = C.finished || !C.launched;
        if ((pdone && (cdone || simT - P.finishT > 1.5f)) || (P.launched && P.launchT > 28.0f))
            finish_race();
    }
}

static void stage_move(Car *c, int forward, int back, float dt)
{
    float sp;
    if (c->staged) return;
    if (c->z < -3.0f) sp = 7.0f; else if (c->z < -1.6f) sp = 3.0f; else sp = 1.4f;
    if (forward) c->z += sp * dt;
    if (back) { c->z -= 1.4f * dt; if (c->z < -12.0f) c->z = -12.0f; }
    if (c->z >= PRESTAGE_Z) c->pre = 1; else c->pre = 0;
    if (c->z >= STAGE_Z) { c->z = STAGE_Z; c->staged = 1; c->pre = 1; }
}

static void update(float dt, unsigned btn, unsigned pressed)
{
    camT += dt;
    if (fbT > 0) fbT -= dt;

    if (phase == PH_MENU) {
        if (pressed & PSP_CTRL_UP)   menuRow = (menuRow + 2) % 3;
        if (pressed & PSP_CTRL_DOWN) menuRow = (menuRow + 1) % 3;
        {
            int d = 0;
            if (pressed & PSP_CTRL_RIGHT) d = 1;
            if (pressed & PSP_CTRL_LEFT)  d = -1;
            if (d) {
                if (menuRow == 0) selClass = (selClass + 3 + d) % 3;
                if (menuRow == 1) selTree  = (selTree + 2 + d) % 2;
                if (menuRow == 2) selDiff  = (selDiff + 3 + d) % 3;
            }
        }
        if (pressed & (PSP_CTRL_CROSS | PSP_CTRL_START)) start_race();
        else show_cars_staged();
        return;
    }

    if (pressed & PSP_CTRL_SELECT) { phase = PH_MENU; show_cars_staged(); return; }
    if (pressed & PSP_CTRL_START) paused ^= 1;
    if (paused) return;

    if (phase == PH_DONE) {
        if (pressed & PSP_CTRL_CROSS)  start_race();
        if (pressed & PSP_CTRL_CIRCLE) { phase = PH_MENU; show_cars_staged(); }
        return;
    }

    throttleHeld = (btn & PSP_CTRL_CROSS) ? 1 : 0;

    /* ---------- estagiar ---------- */
    if (phase == PH_STAGE) {
        stage_move(&P, (btn & PSP_CTRL_UP) != 0, (btn & PSP_CTRL_DOWN) != 0, dt);
        if (simT >= C.aiStageAt) stage_move(&C, 1, 0, dt);
        if (btn & PSP_CTRL_SQUARE) armed = 1; else armed = 0;
        simT += dt; /* relogio corre durante o estagio */
        if (P.staged && C.staged) {
            phase = PH_WAIT;
            waitUntil = simT + 0.8f + frand() * 1.4f;
        }
        return;
    }

    /* ---------- espera / arvore / corrida ---------- */
    if (!P.launched) {
        if (throttleHeld) { rev += dt / 1.1f; if (rev > 1.0f) rev = 1.0f; }
        else              { rev -= dt / 0.8f; if (rev < 0.0f) rev = 0.0f; }
        if (btn & PSP_CTRL_SQUARE) armed = 1;
        else if (armed) {
            do_launch(&P, launch_factor(rev));
            if (P.foul) { fbMsg = "LUZ VERMELHA!"; fbT = 2.5f; }
        }
    } else if (!P.finished && (pressed & PSP_CTRL_RTRIGGER) && P.gear < cls[selClass].gears) {
        float rn = P.rn;
        P.gear++;
        P.shiftCut = 0.09f;
        if (rn > 1.0f)       fbMsg = "TARDE!";
        else if (rn >= 0.90f) fbMsg = "PERFEITO!";
        else                  fbMsg = "CEDO";
        fbT = 0.9f;
    }

    acc += dt;
    while (acc >= H_STEP) {
        sim_tick(H_STEP);
        acc -= H_STEP;
        if (phase == PH_DONE) break;
    }
}

/* ------------------------------------------------------------------ */
/* Desenho: carros                                                     */
/* ------------------------------------------------------------------ */
static void draw_car(const Car *c, float lx, unsigned c1, unsigned c2)
{
    const Cls *k = &cls[selClass];
    ScePspFVector3 t, t2, t3;
    unsigned dark = RGB(25, 25, 28), steel = RGB(170, 170, 180), glass = RGB(20, 30, 45);
    float s;

    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();
    t.x = lx; t.y = 0; t.z = c->z;
    sceGumTranslate(&t);
    t2.x = 0; t2.y = 0; t2.z = -k->ra;
    sceGumTranslate(&t2);
    sceGumRotateX(-c->pitch);
    t3.x = 0; t3.y = 0; t3.z = k->ra;
    sceGumTranslate(&t3);

    cullOn = 0;
    if (selClass == 0) {                       /* TOP FUEL */
        int i;
        box(0, 0.12f, -3.6f, 0.45f, 0.30f, 7.0f, c1);
        box(0, 0.12f, -0.5f, 0.30f, 0.28f, 1.0f, c2);
        box(0, 0.40f, -3.3f, 0.80f, 0.50f, 2.2f, c1);
        box(0, 0.90f, -3.7f, 0.32f, 0.30f, 0.34f, c2);
        box(0, 0.60f, -4.5f, 0.60f, 0.70f, 0.10f, dark);
        box(0, 0.20f, -5.5f, 0.90f, 0.70f, 2.0f, steel);
        box(0, 0.90f, -5.5f, 0.60f, 0.35f, 0.90f, RGB(200, 200, 210));
        box(0, 1.25f, -5.3f, 0.40f, 0.20f, 0.50f, dark);
        for (i = 0; i < 4; i++) {
            box(0.50f, 0.85f, -4.9f - 0.4f * i, 0.10f, 0.45f, 0.10f, RGB(120, 100, 80));
            box(-0.50f, 0.85f, -4.9f - 0.4f * i, 0.10f, 0.45f, 0.10f, RGB(120, 100, 80));
        }
        box(0, 1.90f, -7.4f, 2.40f, 0.08f, 0.90f, c1);
        box(1.25f, 1.40f, -7.4f, 0.06f, 0.90f, 1.10f, c2);
        box(-1.25f, 1.40f, -7.4f, 0.06f, 0.90f, 1.10f, c2);
        box(0.30f, 0.80f, -7.2f, 0.08f, 1.10f, 0.10f, dark);
        box(-0.30f, 0.80f, -7.2f, 0.08f, 1.10f, 0.10f, dark);
        box(0, 0.20f, -0.4f, 1.60f, 0.05f, 0.35f, c1);
        wheel(0.75f, 0.28f, -1.5f, 0.28f, 0.14f, c->wheel * 1.7f);
        wheel(-0.75f, 0.28f, -1.5f, 0.28f, 0.14f, c->wheel * 1.7f);
    } else if (selClass == 1) {                /* FUNNY CAR */
        box(0, 0.25f, -3.9f, 1.80f, 0.50f, 7.2f, c1);
        box(0, 0.75f, -4.3f, 1.50f, 0.20f, 2.6f, c1);
        box(0, 0.95f, -4.35f, 1.52f, 0.22f, 2.0f, glass);
        box(0, 1.17f, -4.4f, 1.40f, 0.10f, 1.6f, c1);
        box(0, 0.05f, -0.2f, 1.90f, 0.06f, 0.5f, dark);
        box(0, 0.75f, -2.2f, 0.70f, 0.40f, 0.9f, steel);
        box(0, 0.50f, -0.6f, 1.00f, 0.10f, 1.2f, c2);
        box(0, 1.90f, -7.6f, 2.50f, 0.08f, 1.0f, c1);
        box(1.30f, 1.40f, -7.6f, 0.06f, 0.90f, 1.2f, c2);
        box(-1.30f, 1.40f, -7.6f, 0.06f, 0.90f, 1.2f, c2);
        box(0.40f, 1.00f, -7.3f, 0.08f, 0.90f, 0.10f, dark);
        box(-0.40f, 1.00f, -7.3f, 0.08f, 0.90f, 0.10f, dark);
        wheel(0.85f, 0.30f, -1.4f, 0.30f, 0.20f, c->wheel * 1.6f);
        wheel(-0.85f, 0.30f, -1.4f, 0.30f, 0.20f, c->wheel * 1.6f);
    } else {                                   /* PRO STOCK */
        box(0, 0.12f, -2.4f, 1.85f, 0.65f, 4.5f, c1);
        box(0, 0.77f, -2.9f, 1.60f, 0.30f, 2.0f, c1);
        box(0, 0.82f, -2.9f, 1.62f, 0.25f, 1.7f, glass);
        box(0, 1.07f, -2.9f, 1.55f, 0.08f, 1.5f, c1);
        box(0, 0.77f, -1.2f, 0.55f, 0.28f, 0.8f, dark);
        box(0, 0.80f, -4.5f, 1.70f, 0.07f, 0.4f, c2);
        box(0.70f, 0.45f, -4.5f, 0.06f, 0.40f, 0.1f, dark);
        box(-0.70f, 0.45f, -4.5f, 0.06f, 0.40f, 0.1f, dark);
        box(0, 0.30f, -0.1f, 1.90f, 0.10f, 0.3f, c2);
        wheel(0.88f, 0.33f, -1.0f, 0.33f, 0.28f, c->wheel);
        wheel(-0.88f, 0.33f, -1.0f, 0.33f, 0.28f, c->wheel);
    }
    /* rodas traseiras */
    s = (selClass == 2) ? 0.90f : (selClass == 1 ? 1.0f : 1.05f);
    wheel(s, k->rrad, -k->ra, k->rrad, (selClass == 2) ? 0.30f : 0.45f, c->wheel);
    wheel(-s, k->rrad, -k->ra, k->rrad, (selClass == 2) ? 0.30f : 0.45f, c->wheel);
    cullOn = 1;

    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();
}

static void draw_smoke(const Car *c, float lx)
{
    const Cls *k = &cls[selClass];
    int i;
    if (!c->launched || c->lf >= 0.92f || c->launchT > 1.7f) return;
    for (i = 0; i < 7; i++) {
        float f = (float)i / 7.0f;
        float al = 150.0f * (1.0f - c->launchT / 1.7f) * (1.0f - f * 0.6f);
        float sz = 0.8f + f * 2.2f + c->launchT;
        unsigned col = RGBA(235, 235, 235, (unsigned)al);
        box(lx + 1.0f, 0.2f + f * 0.6f, c->z - k->ra - 0.8f - f * 2.5f, sz, sz * 0.8f, sz, col);
        box(lx - 1.0f, 0.2f + f * 0.6f, c->z - k->ra - 0.8f - f * 2.5f, sz, sz * 0.8f, sz, col);
    }
}

/* ------------------------------------------------------------------ */
/* Desenho: cenario                                                    */
/* ------------------------------------------------------------------ */
static void tree_lights(int *amb, int *green)
{
    float t;
    *amb = 0; *green = 0;
    if (treeT0 > 1e8f) return;
    t = simT - treeT0;
    if (selTree == 0) {
        if (t >= 0.4f) *green = 1; else if (t >= 0) *amb = 3;
    } else {
        if (t >= 1.5f) *green = 1;
        else if (t >= 1.0f) *amb = 3;
        else if (t >= 0.5f) *amb = 2;
        else if (t >= 0) *amb = 1;
    }
}

static void draw_tree3d(void)
{
    int amb, green, i, lane;
    float z = 14.0f;
    unsigned off = RGB(35, 35, 38);
    tree_lights(&amb, &green);
    box(0, 0.0f, z + 0.5f, 0.5f, 1.0f, 0.5f, RGB(60, 60, 65));
    box(0, 1.0f, z + 0.3f, 3.4f, 3.6f, 0.4f, RGB(18, 18, 20));
    for (lane = 0; lane < 2; lane++) {
        float x = lane == 0 ? 0.85f : -0.85f;
        const Car *c = lane == 0 ? &P : &C;
        int sq = !c->launched;
        box(x, 4.15f, z - 0.05f, 0.5f, 0.35f, 0.2f, (sq && c->pre) ? RGB(255, 255, 255) : off);
        box(x, 3.70f, z - 0.05f, 0.5f, 0.35f, 0.2f, (sq && c->staged) ? RGB(255, 255, 255) : off);
        for (i = 0; i < 3; i++)
            box(x, 3.25f - i * 0.45f, z - 0.05f, 0.5f, 0.35f, 0.2f,
                (i < amb) ? RGB(255, 190, 0) : off);
        box(x, 1.90f, z - 0.05f, 0.5f, 0.35f, 0.2f,
            (green && !c->foul) ? RGB(0, 255, 60) : off);
        box(x, 1.45f, z - 0.05f, 0.5f, 0.35f, 0.2f, c->foul ? RGB(255, 20, 20) : off);
    }
}

static void draw_scene(void)
{
    float z;
    int i, k;

    /* --- chao e pista (painter, sem depth) --- */
    sceGuDisable(GU_DEPTH_TEST);
    plane(-900, -300, 900, 1400, -0.3f, RGB(86, 128, 70));
    plane(-9.5f, -120, 9.5f, 640, -0.2f, RGB(120, 120, 124));      /* acostamento */
    plane(-7.2f, -100, 7.2f, 620, 0.0f, RGB(72, 72, 78));          /* asfalto */
    plane(-7.2f, -30, 7.2f, 60, 0.0f, RGB(52, 52, 58));            /* area de largada borracha */
    plane(-6.0f, 0, -0.9f, 110, 0.0f, RGB(48, 48, 54));
    plane(0.9f, 0, 6.0f, 110, 0.0f, RGB(48, 48, 54));
    plane(-0.12f, -100, 0.12f, 620, 0.0f, RGB(235, 200, 40));      /* linha central */
    plane(-7.0f, -100, -6.85f, 620, 0.0f, RGB(235, 235, 235));
    plane(6.85f, -100, 7.0f, 620, 0.0f, RGB(235, 235, 235));
    plane(-7.2f, -0.15f, 7.2f, 0.15f, 0.0f, RGB(240, 240, 240));   /* linha de largada */
    plane(-7.2f, -1.3f, 7.2f, -1.1f, 0.0f, RGB(200, 200, 200));    /* pre-estagio */
    for (i = 0; i < 24; i++) {                                      /* chegada quadriculada */
        float x0 = -7.2f + i * 0.6f;
        plane(x0, TRACK_LEN, x0 + 0.6f, TRACK_LEN + 0.5f, 0.0f, (i & 1) ? RGB(20, 20, 20) : RGB(245, 245, 245));
        plane(x0, TRACK_LEN + 0.5f, x0 + 0.6f, TRACK_LEN + 1.0f, 0.0f, (i & 1) ? RGB(245, 245, 245) : RGB(20, 20, 20));
    }
    for (k = 1; k <= 3; k++) {                                      /* marcas 330/660/1000 */
        float zz = (k == 1) ? 100.58f : (k == 2 ? 201.17f : 0);
        if (zz > 0) plane(-7.2f, zz - 0.2f, 7.2f, zz + 0.2f, 0.0f, RGB(210, 210, 215));
    }
    sceGuEnable(GU_DEPTH_TEST);

    /* --- montanhas --- */
    {
        static const float mx[9] = {-700, -480, -300, -120, 40, 220, 400, 600, 780};
        static const float mh[9] = {180, 260, 150, 220, 170, 280, 190, 240, 160};
        for (i = 0; i < 9; i++)
            pyramid(mx[i], 900.0f + (float)((i * 37) % 80), 320.0f + (float)((i * 53) % 120), mh[i],
                    (i & 1) ? RGB(120, 110, 100) : RGB(105, 120, 110));
    }

    /* --- postes, placas, muros, arquibancada --- */
    for (z = -76; z < 620; z += 38) {
        for (k = 0; k < 2; k++) {
            float x = k ? 10.2f : -10.2f;
            box(x, 0, z, 0.25f, 9.0f, 0.25f, RGB(150, 150, 155));
            box(x * 0.93f, 9.0f, z, 1.6f, 0.3f, 0.5f, RGB(255, 245, 180));
        }
    }
    for (i = 0; i < 28; i++) {
        float zz = -20.0f + i * 22.0f;
        static const unsigned scol[6] = {RGB(220,30,30), RGB(30,90,220), RGB(240,200,20), RGB(30,160,70), RGB(240,240,240), RGB(230,110,20)};
        box(8.4f, 0, zz, 0.3f, 1.0f, 20.0f, RGB(185, 185, 190));
        box(-8.4f, 0, zz, 0.3f, 1.0f, 20.0f, RGB(185, 185, 190));
        box(8.6f, 0.2f, zz, 0.1f, 0.6f, 14.0f, scol[i % 6]);
        box(-8.6f, 0.2f, zz, 0.1f, 0.6f, 14.0f, scol[(i + 3) % 6]);
    }
    for (k = 0; k < 2; k++) {
        float s = k ? 1.0f : -1.0f;
        for (i = 0; i < 4; i++) {
            box(s * (16.0f + i * 2.2f), 0, 160.0f, 2.2f, 2.0f + i * 1.6f, 300.0f,
                (i & 1) ? RGB(70, 90, 160) : RGB(150, 60, 60));
        }
        for (i = 0; i < 40; i++) {
            float zz = -10.0f + i * 7.5f;
            box(s * (16.0f + (i % 4) * 2.2f), 2.0f + (i % 4) * 1.6f, zz, 1.0f, 0.5f, 1.2f,
                RGB(120 + (i * 37) % 120, 80 + (i * 53) % 150, 80 + (i * 91) % 150));
        }
    }
    box(0, 0, TRACK_LEN + 6.0f, 1.0f, 14.0f, 1.0f, RGB(210, 210, 215));  /* torre */
    box(0, 11.0f, TRACK_LEN + 6.0f, 18.0f, 3.0f, 3.0f, RGB(60, 70, 100));
    box(0, 14.0f, TRACK_LEN + 6.0f, 18.5f, 0.4f, 3.3f, RGB(220, 30, 30));
    box(7.0f, 0, TRACK_LEN + 20.0f, 6.0f, 2.5f, 4.0f, RGB(235, 235, 235)); /* tendas */
    box(-7.0f, 0, TRACK_LEN + 20.0f, 6.0f, 2.5f, 4.0f, RGB(235, 235, 235));
    /* rede de contencao no fim */
    box(0, 0, 600.0f, 18.0f, 4.0f, 0.5f, RGB(230, 120, 30));

    draw_tree3d();
}

/* ------------------------------------------------------------------ */
/* HUD                                                                 */
/* ------------------------------------------------------------------ */
static void hud_tree(void)
{
    int amb, green, i, lane;
    int x0 = 410, y0 = 8;
    unsigned off = RGB(40, 40, 44);
    tree_lights(&amb, &green);
    rect(x0 - 6, y0 - 4, 62, 84, RGBA(0, 0, 0, 160));
    for (lane = 0; lane < 2; lane++) {
        const Car *c = lane == 0 ? &P : &C;
        int x = x0 + lane * 28, sq = !c->launched;
        rect(x, y0, 10, 5, (sq && c->pre) ? RGB(255, 255, 255) : off);
        rect(x, y0 + 8, 10, 5, (sq && c->staged) ? RGB(255, 255, 255) : off);
        for (i = 0; i < 3; i++)
            rect(x, y0 + 17 + i * 11, 14, 9, (i < amb) ? RGB(255, 190, 0) : off);
        rect(x, y0 + 51, 14, 9, (green && !c->foul) ? RGB(0, 255, 60) : off);
        rect(x, y0 + 63, 14, 9, c->foul ? RGB(255, 20, 20) : off);
    }
}

static void hud_tach(void)
{
    const Cls *k = &cls[selClass];
    float v;
    int x = 120, y = 244, w = 240, h = 14, fillw;
    unsigned col;
    char b[32];

    if (!P.launched) v = rev; else v = P.rn;
    if (v > 1.15f) v = 1.15f;

    rect(x - 2, y - 2, w + 4, h + 4, RGBA(0, 0, 0, 170));
    fillw = (int)(w * (v / 1.15f));
    col = (v > 1.0f) ? RGB(255, 40, 40) : (v > 0.88f ? RGB(80, 255, 90) : RGB(60, 170, 255));
    rect(x, y, fillw, h, col);
    /* janela ideal */
    if (!P.launched) {
        int a = x + (int)(w * 0.72f / 1.15f), bb = x + (int)(w * 0.88f / 1.15f);
        rect(a, y - 4, 2, h + 8, RGB(255, 255, 0));
        rect(bb, y - 4, 2, h + 8, RGB(255, 255, 0));
    } else {
        int a = x + (int)(w * 0.90f / 1.15f), bb = x + (int)(w * 1.0f / 1.15f);
        rect(a, y - 4, 2, h + 8, RGB(255, 255, 0));
        rect(bb, y - 4, 2, h + 8, RGB(255, 60, 60));
    }
    snprintf(b, sizeof b, "MARCHA %d/%d", P.gear, k->gears);
    text(8, 246, 2, RGB(255, 255, 255), b);
}

static void hud_progress(void)
{
    int x = 140, y = 14, w = 200;
    float pp = P.z / TRACK_LEN, cp = C.z / TRACK_LEN;
    if (pp < 0) pp = 0;
    if (pp > 1) pp = 1;
    if (cp < 0) cp = 0;
    if (cp > 1) cp = 1;
    rect(x, y, w, 4, RGBA(255, 255, 255, 120));
    rect(x + w - 2, y - 4, 3, 12, RGB(255, 255, 255));
    rect(x + (int)(pp * w) - 3, y - 3, 7, 10, RGB(255, 60, 60));
    rect(x + (int)(cp * w) - 3, y - 3, 7, 10, RGB(60, 120, 255));
}

static void draw_hud(void)
{
    char b[64];
    int mph = (int)(P.v * MS2MPH + 0.5f);

    if (phase == PH_MENU) {
        static const char *cn[3] = {"TOP FUEL", "FUNNY CAR", "PRO STOCK"};
        static const char *tn[2] = {"PRO (RAPIDA)", "SPORTSMAN"};
        static const char *dn[3] = {"FACIL", "MEDIO", "DIFICIL"};
        int i;
        rect(60, 16, 360, 240, RGBA(0, 0, 0, 175));
        textC(26, 4, RGB(255, 210, 40), "NHRA");
        textC(60, 2, RGB(255, 255, 255), "DRAG RACING 3D");
        for (i = 0; i < 3; i++) {
            const char *lab = i == 0 ? "CLASSE" : (i == 1 ? "ARVORE" : "OPONENTE");
            const char *val = i == 0 ? cn[selClass] : (i == 1 ? tn[selTree] : dn[selDiff]);
            unsigned col = (i == menuRow) ? RGB(255, 230, 80) : RGB(200, 200, 200);
            snprintf(b, sizeof b, "%s", lab);
            text(80, 96 + i * 26, 2, col, b);
            snprintf(b, sizeof b, "< %s >", val);
            text(230, 96 + i * 26, 2, col, b);
        }
        if (bestET[selClass] > 0) {
            snprintf(b, sizeof b, "MELHOR ET: %.3f", bestET[selClass]);
            textC(180, 2, RGB(120, 255, 140), b);
        }
        textC(206, 2, RGB(255, 255, 255), "X = COMECAR");
        textC(228, 1, RGB(170, 170, 170), "FAN GAME - SEM RELACAO COM A NHRA");
        return;
    }

    /* velocimetro */
    snprintf(b, sizeof b, "%d", mph);
    text(8, 8, 4, RGB(255, 255, 255), b);
    text(8, 40, 2, RGB(200, 200, 200), "MPH");
    if (P.timerOn) {
        float t = P.finished ? P.et : P.timer;
        snprintf(b, sizeof b, "ET %.3f", t);
        text(8, 60, 2, RGB(255, 230, 80), b);
    }
    if (P.launched) {
        if (P.foul) snprintf(b, sizeof b, "RT LUZ VERMELHA");
        else snprintf(b, sizeof b, "RT %.3f", P.rt);
        text(8, 82, 2, P.foul ? RGB(255, 60, 60) : RGB(120, 255, 160), b);
    }
    hud_tree();
    hud_progress();
    hud_tach();

    if (fbT > 0) textC(200, 3, RGB(255, 255, 255), fbMsg);

    if (phase == PH_STAGE) {
        textC(100, 2, RGB(255, 255, 255), "SEGURE CIMA PARA ESTAGIAR");
        textC(122, 2, RGB(255, 220, 80), "SEGURE QUADRADO");
    } else if (phase == PH_WAIT || (phase == PH_TREE && !P.launched)) {
        if (simT < greenT) {
            textC(100, 2, RGB(255, 220, 80), "SEGURE QUADRADO + X");
            textC(122, 1, RGB(255, 255, 255), "SOLTE O QUADRADO NO VERDE");
        } else {
            textC(100, 3, RGB(0, 255, 80), "SOLTE!");
        }
    } else if (phase == PH_TREE && P.launched && P.launchT < 3.0f && !P.foul) {
        textC(100, 1, RGB(255, 255, 255), "X = ACELERAR   R = TROCAR MARCHA");
    }
    if (paused) {
        rect(150, 100, 180, 50, RGBA(0, 0, 0, 200));
        textC(116, 3, RGB(255, 255, 255), "PAUSA");
    }
    if (phase == PH_DONE) {
        int y = 30;
        rect(40, 14, 400, 220, RGBA(0, 0, 0, 205));
        if (winner == 1) textC(y, 3, RGB(90, 255, 120), "VOCE VENCEU!");
        else             textC(y, 3, RGB(255, 80, 80), P.foul ? "LUZ VERMELHA - DERROTA" : "VOCE PERDEU");
        text(60, y + 36, 1, RGB(160, 160, 160), "TIMESLIP");
        text(250, y + 36, 1, RGB(255, 110, 110), "VOCE");
        text(340, y + 36, 1, RGB(110, 160, 255), "CPU");
        {
            static const char *lab[6] = {"REACAO", "60 FT", "330 FT", "660 FT", "1000 FT ET", "VEL FINAL MPH"};
            float pv[6], cv[6];
            int i;
            pv[0] = P.rt; cv[0] = C.rt;
            pv[1] = P.t60; cv[1] = C.t60;
            pv[2] = P.t330; cv[2] = C.t330;
            pv[3] = P.t660; cv[3] = C.t660;
            pv[4] = P.et; cv[4] = C.et;
            pv[5] = P.mph; cv[5] = C.mph;
            for (i = 0; i < 6; i++) {
                int yy = y + 52 + i * 18;
                text(60, yy, 1, RGB(230, 230, 230), lab[i]);
                if (i == 0 && P.foul) snprintf(b, sizeof b, "RED");
                else if (pv[i] <= 0 && i != 0) snprintf(b, sizeof b, "--");
                else if (i == 5) snprintf(b, sizeof b, "%.1f", pv[i]);
                else snprintf(b, sizeof b, "%.3f", pv[i]);
                text(250, yy, 2, RGB(255, 255, 255), b);
                if (cv[i] <= 0 && i != 0) snprintf(b, sizeof b, "--");
                else if (i == 5) snprintf(b, sizeof b, "%.1f", cv[i]);
                else snprintf(b, sizeof b, "%.3f", cv[i]);
                text(340, yy, 2, RGB(255, 255, 255), b);
            }
        }
        if (winMargin > 0) {
            snprintf(b, sizeof b, "MARGEM %.3f S", winMargin);
            textC(y + 168, 1, RGB(255, 230, 80), b);
        }
        textC(y + 184, 1, RGB(200, 200, 200), "X = CORRER DE NOVO     O = MENU");
    }
}

/* ------------------------------------------------------------------ */
/* Render                                                              */
/* ------------------------------------------------------------------ */
static void draw_sky(void)
{
    V *v = alloc_v(6);
    unsigned top = RGB(60, 110, 200), bot = RGB(190, 215, 240);
    if (!v) return;
    v[0].c = top; v[0].x = 0;      v[0].y = 0;     v[0].z = 0;
    v[1].c = top; v[1].x = SCR_W;  v[1].y = 0;     v[1].z = 0;
    v[2].c = bot; v[2].x = SCR_W;  v[2].y = 150;   v[2].z = 0;
    v[3].c = top; v[3].x = 0;      v[3].y = 0;     v[3].z = 0;
    v[4].c = bot; v[4].x = SCR_W;  v[4].y = 150;   v[4].z = 0;
    v[5].c = bot; v[5].x = 0;      v[5].y = 150;   v[5].z = 0;
    sceGuDrawArray(GU_TRIANGLES, VT2, 6, 0, v);
}

static void render(void)
{
    ScePspFVector3 eye, at, up;
    float fov, back, shake;

    pn = 0;
    sceGuStart(GU_DIRECT, dlist);
    sceGuClearColor(RGB(190, 215, 240));
    sceGuClearDepth(0);
    sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);

    sceGuDisable(GU_DEPTH_TEST);
    sceGuDisable(GU_FOG);
    draw_sky();

    /* camera */
    up.x = 0; up.y = 1; up.z = 0;
    if (phase == PH_MENU) {
        float ang = camT * 0.35f;
        eye.x = 15.0f * sinf(ang);
        eye.y = 4.0f;
        eye.z = -4.0f - 15.0f * cosf(ang);
        at.x = 0; at.y = 0.9f; at.z = -4.0f;
        fov = 55.0f;
        camZ = -4.0f - 40.0f;
    } else {
        float sp = P.v;
        back = 11.0f + sp * 0.025f;
        shake = (sp > 5.0f) ? sinf(camT * 47.0f) * 0.012f * (sp / 100.0f) : 0.0f;
        eye.x = 1.9f + shake;
        eye.y = 2.4f + sp * 0.004f;
        eye.z = P.z - back;
        at.x = 1.5f; at.y = 1.1f; at.z = P.z + 16.0f;
        fov = 58.0f + sp * 0.07f;
        camZ = eye.z;
    }

    sceGumMatrixMode(GU_PROJECTION);
    sceGumLoadIdentity();
    sceGumPerspective(fov, (float)SCR_W / (float)SCR_H, 1.0f, 1500.0f);
    sceGumMatrixMode(GU_VIEW);
    sceGumLoadIdentity();
    sceGumLookAt(&eye, &at, &up);
    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();

    sceGuFog(120.0f, 900.0f, RGB(190, 215, 240));
    sceGuEnable(GU_FOG);

    draw_scene();
    draw_car(&C, LANE_C, RGB(30, 80, 220), RGB(250, 215, 30));
    draw_car(&P, LANE_P, RGB(220, 28, 36), RGB(245, 245, 245));

    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
    draw_smoke(&P, LANE_P);
    draw_smoke(&C, LANE_C);

    /* HUD 2D */
    sceGuDisable(GU_DEPTH_TEST);
    sceGuDisable(GU_FOG);
    draw_hud();
    sceGuDisable(GU_BLEND);
    sceGuEnable(GU_DEPTH_TEST);

    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

static void init_gu(void)
{
    sceGuInit();
    sceGuStart(GU_DIRECT, dlist);
    sceGuDrawBuffer(GU_PSM_8888, (void *)0, BUF_W);
    sceGuDispBuffer(SCR_W, SCR_H, (void *)0x88000, BUF_W);
    sceGuDepthBuffer((void *)0x110000, BUF_W);
    sceGuOffset(2048 - (SCR_W / 2), 2048 - (SCR_H / 2));
    sceGuViewport(2048, 2048, SCR_W, SCR_H);
    sceGuDepthRange(0xc350, 0x2710);
    sceGuScissor(0, 0, SCR_W, SCR_H);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDepthFunc(GU_GEQUAL);
    sceGuEnable(GU_DEPTH_TEST);
    sceGuFrontFace(GU_CW);
    sceGuShadeModel(GU_SMOOTH);
    sceGuDisable(GU_CULL_FACE);
    sceGuDisable(GU_TEXTURE_2D);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
}

int main(void)
{
    SceCtrlData pad;
    unsigned oldBtn = 0;
    u64 last, now;
    u32 res;

    setup_callbacks();
    sceRtcGetCurrentTick(&last);
    res = sceRtcGetTickResolution();
    srand((unsigned)last);

    init_gu();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);

    show_cars_staged();

    for (;;) {
        float dt;
        unsigned btn, pressed;

        sceRtcGetCurrentTick(&now);
        dt = (float)((double)(now - last) / (double)res);
        last = now;
        if (dt > 0.05f) dt = 0.05f;
        if (dt < 0.0f) dt = 0.0f;

        sceCtrlPeekBufferPositive(&pad, 1);
        btn = pad.Buttons;
        /* analogico como direcional */
        if (pad.Ly < 60)  btn |= PSP_CTRL_UP;
        if (pad.Ly > 200) btn |= PSP_CTRL_DOWN;
        pressed = btn & ~oldBtn;
        oldBtn = btn;

        update(dt, btn, pressed);
        render();
    }
    return 0;
}
